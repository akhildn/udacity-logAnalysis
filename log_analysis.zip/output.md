#POPULAR ARTICLES

| Article Title |	# views  |
|---------------|:----------:|
| Candidate is jerk, alleges rival   | 	338647 |
| Bears love berries, alleges bear   | 	253801 | 
| Bad things gone, say good people   |	170098 |



#POPULAR AUTHORS

| Author Name 	| # views |
|---------------|:---------:|
| Ursula La Multa        | 	507594 |
| Rudolf von Treppenwitz |	423457 | 
| Anonymous Contributor  | 	170098 |
| Markoff Chaney 	     |   84557 |

#Errors

| Date 	     | Error rate |
|------------|------------|
| 2016-07-17 |	2.2626862468027260 |